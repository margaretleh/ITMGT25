# ITMGT 25.03
## Intersession 2022

This repository contains programming resources for ITMGT 25.03, Intersession 2022.

## `individual-programming-assignment-templates/`
This folder contains the templates for the individual programming assignments.

## `summative-assessment-scaffolding/`
This folder contains resources that may help you in the summative assessments.
